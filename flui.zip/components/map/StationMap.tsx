import { useCallback, useMemo, useRef } from 'react'
import { StyleSheet, View } from 'react-native'
import { WebView, type WebViewMessageEvent } from 'react-native-webview'
import { buildMapHtml } from './mapHtml'
import type { StationMapProps } from './types'
import { useMapBridge } from './useMapBridge'

/**
 * Versão nativa (iOS/Android). Usa Leaflet dentro de um WebView, o que:
 * - funciona no Expo Go e em development builds sem chave do Google Maps;
 * - mantém o visual neon idêntico ao da versão web (StationMap.web.tsx).
 */
export function StationMap({ bottomInset, ...props }: StationMapProps) {
  const webViewRef = useRef<WebView>(null)

  const html = useMemo(() => buildMapHtml({ bottomInset }), [bottomInset])

  const send = useCallback((message: Record<string, unknown>) => {
    // \u2028/\u2029 quebram string JS em alguns WebViews
    const json = JSON.stringify(message)
      .replace(/\u2028/g, '\\u2028')
      .replace(/\u2029/g, '\\u2029')

    webViewRef.current?.injectJavaScript(
      `window.__flui && window.__flui.receive(${json}); true;`
    )
  }, [])

  const { handleMessage } = useMapBridge({ ...props, send })

  return (
    <View style={StyleSheet.absoluteFill}>
      <WebView
        ref={webViewRef}
        source={{ html, baseUrl: 'https://flui.local' }}
        originWhitelist={['*']}
        javaScriptEnabled
        domStorageEnabled
        onMessage={(event: WebViewMessageEvent) =>
          handleMessage(event.nativeEvent.data)
        }
        onLoadEnd={() => send({ type: 'hello' })}
        scrollEnabled={false}
        bounces={false}
        overScrollMode="never"
        setSupportMultipleWindows={false}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        style={styles.webView}
        containerStyle={styles.container}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#05050c',
  },
  webView: {
    flex: 1,
    backgroundColor: '#05050c',
  },
})
