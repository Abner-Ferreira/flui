import { useCallback, useEffect, useMemo, useRef } from 'react'
import { StyleSheet, View } from 'react-native'
import { buildMapHtml } from './mapHtml'
import type { StationMapProps } from './types'
import { useMapBridge } from './useMapBridge'

/**
 * Versão web. O mesmo documento HTML/Leaflet da versão nativa, dentro de um iframe.
 * Rodar isolado no iframe evita problemas de SSR/bundle com o Leaflet e mantém
 * o visual idêntico ao do app.
 */
export function StationMap({ bottomInset, ...props }: StationMapProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null)

  const html = useMemo(() => buildMapHtml({ bottomInset }), [bottomInset])

  const send = useCallback((message: Record<string, unknown>) => {
    iframeRef.current?.contentWindow?.postMessage(
      { ...message, __flui: true },
      '*'
    )
  }, [])

  const { handleMessage } = useMapBridge({ ...props, send })

  useEffect(() => {
    function onMessage(event: MessageEvent) {
      // Só aceita mensagens vindas do nosso iframe
      if (event.source !== iframeRef.current?.contentWindow) return
      handleMessage(event.data)
    }

    window.addEventListener('message', onMessage)
    return () => window.removeEventListener('message', onMessage)
  }, [handleMessage])

  return (
    <View style={StyleSheet.absoluteFill}>
      <iframe
        ref={iframeRef}
        title="Mapa de estações de recarga"
        srcDoc={html}
        onLoad={() => send({ type: 'hello' })}
        style={{
          border: 'none',
          width: '100%',
          height: '100%',
          display: 'block',
          backgroundColor: '#05050c',
        }}
      />
    </View>
  )
}
